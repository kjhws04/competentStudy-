﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithm
{
    class Board
    {
        const char CIRCLE = '\u25cf';
        public TileType[,] Tile { get; private set; }
        public int Size { get; private set; }

        public int DestY { get; private set; }
        public int DestX { get; private set; }

        Player _player;

        public enum TileType
        {
            Empty,
            Wall,
        }

        public void Initialize(int size, Player player)
        {
            if (size % 2 == 0)
                return;

            _player = player;

            Tile = new TileType[size, size];
            Size = size;

            DestX = size - 2;
            DestY = size - 2;

            //GenerateByBinaryTree();
            GenerateBySideWinder();
        }

        void GenerateByBinaryTree()
        {
            //길을 다 막아버리는 작업
            for (int x = 0; x < Size; x++)
            {
                for (int y = 0; y < Size; y++)
                {
                    if (x % 2 == 0 || y % 2 == 0)
                        Tile[x, y] = TileType.Wall;
                    else
                        Tile[x, y] = TileType.Empty;
                }
            }
            Random rand = new Random();

            //랜덤으로 우측 혹은 아래로 길을 뚫는 작업
            // BinaryTree 알고리즘
            for (int x = 0; x < Size; x++)
            {
                for (int y = 0; y < Size; y++)
                {
                    if (x % 2 == 0 || y % 2 == 0)
                        continue;

                    if (y == Size - 2 && x == Size - 2)
                        continue;

                    if (x == Size - 2)
                    {
                        Tile[x, y + 1] = TileType.Empty;
                        continue;
                    }

                    if (y == Size - 2)
                    {
                        Tile[x + 1, y] = TileType.Empty;
                        continue;
                    }

                    if (rand.Next(0, 2) == 0)
                    {
                        Tile[x, y + 1] = TileType.Empty;
                    }
                    else
                    {
                        Tile[x + 1, y] = TileType.Empty;
                    }
                }
            }
        }
        void GenerateBySideWinder()
        {
            //길을 다 막아버리는 작업
            for (int x = 0; x < Size; x++)
            {
                for (int y = 0; y < Size; y++)
                {
                    if (x % 2 == 0 || y % 2 == 0)
                        Tile[x, y] = TileType.Wall;
                    else
                        Tile[x, y] = TileType.Empty;
                }
            }
            Random rand = new Random();

            //랜덤으로 우측 혹은 아래로 길을 뚫는 작업
            for (int x = 0; x < Size; x++)
            {
                int count = 1;
                for (int y = 0; y < Size; y++)
                {
                    if (x % 2 == 0 || y % 2 == 0)
                        continue;

                    if (y == Size - 2 && x == Size - 2)
                        continue;

                    if (x == Size - 2)
                    {
                        Tile[x, y + 1] = TileType.Empty;
                        continue;
                    }

                    if (y == Size - 2)
                    {
                        Tile[x + 1, y] = TileType.Empty;
                        continue;
                    }

                    if (rand.Next(0, 2) == 0)
                    {
                        Tile[x, y + 1] = TileType.Empty;
                        count++;
                    }
                    else
                    {
                        int randonIndex = rand.Next(0, count);
                        Tile[x + 1, y - randonIndex * 2] = TileType.Empty;
                        count = 1;
                    }
                }
            }
        }

        public void Render()
        {
            ConsoleColor prevColor = Console.ForegroundColor;

            for (int y = 0; y < Size; y++)
            {
                for (int x = 0; x < Size; x++)
                {
                    //플레이어 좌표를 가지고 와서 일치하면 플레이어 전용 색상 표시
                    if(x == _player.PosX && y == _player.PosY)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                    }
                    else if (y == DestY && x == DestX)
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    else
                        Console.ForegroundColor = GetTileColor(Tile[y, x]);
                    Console.Write(CIRCLE);
                }
                Console.WriteLine();
            }
            Console.ForegroundColor = prevColor;
        }

        ConsoleColor GetTileColor(TileType type)
        {
            switch (type)
            {
                case TileType.Empty:
                    return ConsoleColor.Green;
                case TileType.Wall:
                    return ConsoleColor.Red;
                default:
                    return ConsoleColor.Green;
            }
        }
    }
}
